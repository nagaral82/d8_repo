(function ($, Drupal) {
    "use strict";
	var is_clicked = false;
    Drupal.behaviors.searchFilters = {
        attach: function (context) {
			var fullAddress='';			
			$('.locate-me-isha-a').click(function(e) {
				$(".locateLoader").html('<div class="ajax-progress ajax-progress-fullscreen">&nbsp;</div>');
				$(".locateLoader").css("display", "block");
				geolocator.config({
					language: "en",
					google: {
						version: "3",
						key: drupalSettings.isha_prog_events.gmap_key
					}
				});
				var options = {
					enableHighAccuracy: true,
					fallbackToIP: false, // fallback to IP if Geolocation fails or rejected
					addressLookup: true
				};
				geolocator.locate(options, function (err, location) {
                    var city = '';
					if (err) {
						city = drupalSettings.isha_prog_events.location_city;
						fullAddress = city;
					}
					else {
						city = location.address.city;
						fullAddress = city;
					}
					$('#localcentersearch').val(fullAddress);
					$(".locateLoader").html('');
				});
					
			});
			
			$("#views-exposed-form-external-json-data-block-1 input, #views-exposed-form-external-json-data-block-1 select").click(function(){
					// A form element was clicked
					is_clicked = true;
			});
			if (drupalSettings.isha_prog_events.programs_api1 !== undefined && drupalSettings.isha_prog_events.programs_api1 !== null) {
				//console.log($._data(elem, 'events'));
				if (!is_clicked) {
				$('.view-external-json-data .view-empty').html('<div class="ajax-progress ajax-progress-fullscreen">&nbsp;</div>');
				$('.view-external-json-data .view-content').html('<div class="ajax-progress ajax-progress-fullscreen">&nbsp;</div>');
				geolocator.config({
					language: "en",
					google: {
						version: "3",
						key: drupalSettings.isha_prog_events.gmap_key
					}
				});
				var options = {
					enableHighAccuracy: true,
					fallbackToIP: false, // fallback to IP if Geolocation fails or rejected
					addressLookup: false
				};
				geolocator.locate(options, function (err, location) {
					if (!err) {
                                            var data = {
                                                    "latitude" : location.coords.latitude,
                                                    "longitude" : location.coords.longitude
                                            }; 
                                        }
                                        else {
                                            var data = {};
                                        }
					jQuery.post('/browser_geo_location',data,function(response){							
								$('#views-exposed-form-external-json-data-block-1 .btn-filter-submit').trigger("click");
								is_clicked = true;
							
							
							
					});
				});
				}
			}
        }
    };
})(jQuery, Drupal);
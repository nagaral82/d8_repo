(function ($, Drupal) {
    "use strict";
    Drupal.behaviors.programCardFilters = {
        attach: function (context) {
			$('#views-bootstrap-monthly-event-gird-view-block-1 .row .col').addClass('card-filter');
			var baseUrl = window.location.href.split('?')[0] ;
			var spanVal = '';
			var queryString = window.location.search;
			var str = queryString.split("=")[1];
			spanVal = str ? str : '';
			$('.card-filter-options').each(function() {
				$(this).click(function(e) {
					if($(this).hasClass('active')) {
						$(this).removeClass('active');
						showFilterCard();
						var arr = spanVal.split(',');
						var spanParent = $(this).text();
						var trimParent = $.trim(spanParent);
						for(var i = arr.length - 1; i >= 0; i--) {
							if(arr[i] == trimParent) {
								arr.splice(i, 1);
							}
						}				 
						spanVal = arr.length ? arr.join(',') : '';
						var urlQueryRemove = baseUrl;
						if(spanVal) {
							urlQueryRemove += "?data=" + spanVal;
						}
						window.history.pushState({path:urlQueryRemove},'',urlQueryRemove);
						e.stopPropagation();
					}
					else {
						$(this).addClass('active');
						showFilterCard();
						spanVal = spanVal+','+$(this).children('span').text();
						if(spanVal.charAt(0) == ','){
							spanVal = spanVal.substring(1);
						}
						var urlQueryAdd = baseUrl+"?data=" + spanVal;
						window.history.pushState({path:urlQueryAdd},'',urlQueryAdd);
						e.stopPropagation();
						
					}
				});
				/*$(this).children('a').click(function(e) {
					$(this).parent().removeClass('active');
					showFilterCard();
					var arr = spanVal.split(',');
					var spanParent = $(this).parent().text();
					var trimParent = $.trim(spanParent);
					for(var i = arr.length - 1; i >= 0; i--) {
						if(arr[i] == trimParent) {
							arr.splice(i, 1);
						}
					}				 
					spanVal = arr.length ? arr.join(',') : '';
					var urlQueryRemove = baseUrl;
					if(spanVal) {
						urlQueryRemove += "?data=" + spanVal;
					}
					window.history.pushState({path:urlQueryRemove},'',urlQueryRemove);
					e.stopPropagation();
				});*/
				

				if(str != null){
					var urlValue = str.split(",");
					var spanNewVal = $(this).children('span').text()
					if (spanNewVal == urlValue[0] || spanNewVal == urlValue[1] || spanNewVal == urlValue[2] || spanNewVal == urlValue[3] || spanNewVal == urlValue[4]) {
						$(this).addClass('active');
						showFilterCard();
					}else{
						$(this).removeClass('active');
						showFilterCard();
					}
				}
			});
		function showFilterCard() {
				if($('.card-filter-options.active').length > 0) {
					$(".card-filter").hide();
					$('.card-filter-options.active').each(function(){
						var active_filter = $(this).find('span').text();
						$(".card-filter").each(function() {
							var ribData = $(this).find('.ribbon-data').attr('data');
							if(ribData){
								var ribStrip = ribData.replace(/\s+/g, '');
								var rib = ribStrip.split(",");
								var strFirst = rib[0];
								var strSec = rib[1];
								var strThr = rib[2];
								var strFor = rib[3];
								var strFiv = rib[4];
							}
							if (strFirst == active_filter || strSec == active_filter || strThr == active_filter || strFor == active_filter || strFiv == active_filter) {
								var getFilter = active_filter;
								$(this).fadeIn(500);
							}
						});
					});
				}
				else {
					$(".card-filter").fadeIn(500);
				}
			}
        }
    };
})(jQuery, Drupal);
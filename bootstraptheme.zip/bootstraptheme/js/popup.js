var config = {
							    apiKey: drupalSettings.isha_autologin.apiKey,
							    authDomain: drupalSettings.isha_autologin.authDomain,
							    databaseURL: drupalSettings.isha_autologin.databaseURL,
							    projectId: drupalSettings.isha_autologin.projectId,
							    storageBucket: drupalSettings.isha_autologin.storageBucket,
							    messagingSenderId: drupalSettings.isha_autologin.messagingSenderId
							  };

(function ($, Drupal) {
	"use strict";
	Drupal.behaviors.loginPMS = {
		attach: function (context) {
			$("#myLogin").on('show.bs.modal', function () {
				$('body').addClass('body-fixed');
			});
			$("#myLogin").on('hide.bs.modal', function () {
				$('body').removeClass('body-fixed');
			});
			// For Datepicker	
			    var $datepicker = $(context).find('input[jquery-ui-date-format]');
			    if ($datepicker.length) {
			    	$datepicker.datepicker(
							{ 
								dateFormat: $datepicker.attr('jquery-ui-date-format'),
								changeMonth: true,
							    changeYear: true,
							    yearRange: "-100:+0", 
								maxDate: new Date(),
							}
					);
			    }
			    
				// Login or Signup Link in Navigation bar Click Event
				$(".loginLink, .signUp").on('click', function() {
					
					if (typeof($(this).data('redirect_url')) !== "undefined" && $(this).data('redirect_url') != '') {
						drupalSettings.isha_autologin.current_url = $(this).data('redirect_url');						
					}

			        if ($(this).hasClass('loginLink')) {
						$('#my_iframe').attr('src', drupalSettings.isha_autologin.angular_api_url);	
			        } else {
						$('#my_iframe').attr('src', drupalSettings.isha_autologin.angular_api_signup_url);
					}
			    });
				
				$("#my_iframe").on("load", function () {
					var data = {
			                'applicationId':  parseInt(drupalSettings.isha_autologin.angular_api_key),
			                'redirecturl' : drupalSettings.isha_autologin.current_url
			        };
			        var apiurl = drupalSettings.isha_autologin.angular_api_signup_url;					
					
					document.getElementById("my_iframe").contentWindow.postMessage(data,apiurl);
				});
				if($('.block-views-blockupcoming-programs-for-centres-new-block-1').length > 0){
					$('.registration-model-window button.close').click(function(){
							history.replaceState('data to be passed', 'Title of the page', drupalSettings.isha_autologin.current_url);
					})
				}
				$(window).on("message onmessage", function(e) {
	
					if (e.originalEvent.data.userUid !== undefined && e.originalEvent.data.userUid !== null) {
						//alert(e.originalEvent.data.userUid);
						var firebase_data = {
							   'autologin_profile_id' : e.originalEvent.data.userUid,
							   'autologin_provider_id' : e.originalEvent.data.providerId,
						};
						
						// Showing Loader
						$('.loader-login').show();
						firebase.initializeApp(config);
						var database = firebase.database();
						
						// Redirect to main application
						if (firebase !== undefined && firebase !== null) {
							firebase.database().goOnline();
							
							var redirecturl = e.originalEvent.data.redirecturl;
							// User Registry
							var leadsRef = database.ref('userRegistry/'+e.originalEvent.data.userUid);

							leadsRef.on('value', function(snapshot) {
								snapshot.forEach(function(childSnapshot) {
									firebase_data['autologin_'+childSnapshot.key] = childSnapshot.val();
								});
								$.post('/autologin/callback',firebase_data,function(response){
									window.location = (redirecturl) ? redirecturl : drupalSettings.isha_autologin.home_url;
									$(window).load(function() {
										$('#myLogin').modal('hide');
										firebase.database().goOffline();
									});
								});
							});
							
						}
						
						// After Sign up from email is completed this data will be received and modal will be closed after 5 seconds
						// For showing "Verification email has been sent message", pop up will be shown for 5 seconds  
						if(e.originalEvent.data === 'Close Popup') {
							var frameElement = document.getElementById("my_iframe");
							frameElement.contentWindow.location.href = frameElement.src;
							setTimeout(function() {$('#myLogin').modal('hide');}, 5000);
						} 
					}						
					if(e.originalEvent.data === 'Show Terms Of Service') {
						window.open(drupalSettings.isha_autologin.angular_terms_and_condition_url, '_blank');
					}
					if(e.originalEvent.data === 'Show Privacy Policy') {
						window.open(drupalSettings.isha_autologin.angular_privacy_policy_url, '_blank');
					}
				});
				
				// Join online	
				jQuery('.disable-right-click').bind('contextmenu', function(e){return false;});
				
				/*jQuery('.anony-login-popup').on('click', function(e) {
					jQuery('#myLogin').modal('show');
				});*/
				jQuery('#sitwide_ks_events').on('click', function(e) {
					var userid = drupalSettings.isha_autologin.autologinJS.currentuser;
					if(userid ==0){
						jQuery( "#topLogin" ).click();
						return false;
					} else {
						var title =  jQuery('#event_ks_title').text();
						var webinar = jQuery("#sitwide_ks_events").attr("href");
						var data = {
								"title": title,  // required
						};
						jQuery.ajax ({
							dataType: "json",
							type: "POST",
							url: "/autologin/joinonline",
							data: data,
							success: function(data, status, xhr) {
							//alert('status: ' + status + ', data: ' + data.redirectURL+ ', data: ' + data.errorCode);
							//if(data.redirectURL =="http://dev.isha.sadhguru.org/subs-failure/")
							//{
							//alert('dd');
							//}else{
								window.location =  webinar;
							//}
							},
						}); 
						return false;
					}
				});
		}		
	};
})(jQuery, Drupal);
 (function ($, Drupal) {
    "use strict";
    //Drupal.AjaxCommands.prototype.getEvents = function(ajax, response, status){ }

    Drupal.behaviors.wisdomOptions = {
        attach: function (context) {
            /**** First letter design caption ***/
            Drupal.wisdomGrid = {};
            Drupal.wisdomGrid.container = {};

	        //$('.isha-wisdom-landing-page', context).once('wisdomLandingPage2').each(function() { 
            if($(".wpost")){
                Drupal.wisdomGrid.gutter = parseInt(jQuery('.wpost').css('marginBottom'));
                Drupal.wisdomGrid.container = jQuery('.isha-landing-main-content .views-view-grid');
                var gutter = Drupal.wisdomGrid.gutter;

                Drupal.wisdomGrid.container.imagesLoaded( function() {
	                //Drupal.wisdomGrid.container.masonry('destroy');
	                Drupal.wisdomGrid.container.masonry({
					  	gutter: gutter,
					  	itemSelector: '.wpost',
	                    columnWidth: '.wpost',
                        horizontalOrder: true
					});
				});
            }
	        //});

            $('.isha-wisdom-landing-page', context).once('wisdomLandingPage').each(function() {
                mobileRenderFilter();
                $(document).ajaxSuccess(function(event, request, settings) {
                    mobileRenderFilter();
                });
                
                $(document).on('click','.mob-show-filter', function() {
                    $('.filters-expanded').toggle(500);
                });
            });           

            function mobileRenderFilter() {
                var isMobile = window.matchMedia("only screen and (max-width: 760px)");
                if (isMobile.matches) {
                    if($('.isha-landing-main-content > .view-filters')) {
                        renderElement();
                    }
                }
            }

            function renderElement() {
                if($('.mob-show-filter').length == 0) {
                    $("<div class='mob-show-filter'>Filters <b class='caret'></b></div>").insertBefore('.form-item-sort-bef-combine');
                }
                if($('.filters-expanded').length == 0) {
                    $("<div id='filter-mobile' class='filters-expanded' style='display:none'></div>").insertAfter('.form-item-sort-bef-combine');
                }

                $('.form-item-combine').detach().insertBefore('.mob-show-filter');
                $('.form-item-langcode').detach().appendTo('#filter-mobile');
                $('.form-item-topic').detach().appendTo('#filter-mobile');
                $('.form-item-type').detach().appendTo('#filter-mobile');                
            }
        }
    };
})(jQuery, Drupal);


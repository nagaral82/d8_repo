function onScroll2(event) {
    var scrollPos = jQuery(document).scrollTop() -200;
    jQuery('#left-menu-center-hytt a').each(function() {
        var currLink = jQuery(this);      
        var divId = "#"+this.href.substr(this.href.lastIndexOf('/') + 1);
        var refElement = jQuery(divId);
        if(jQuery(divId).length) {
            if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
              jQuery('#left-menu-center-hytt li.active').removeClass('active');
              jQuery(currLink).parent().addClass('active');
              jQuery('#left-menu-center-hytt ul li.active a').removeClass("active");
              currLink.addClass("active");
              history.pushState({}, null, currLink.attr("href"));
            } else {
                currLink.removeClass("active");
            }
        }
    });
}
(function ($, Drupal) {
	"use strict";
	Drupal.behaviors.localOptions = {
		attach: function (context) {
			Drupal.localGrid = {};
			Drupal.localGrid.container = {};
			if($(".lpost")){
				Drupal.localGrid.gutter = parseInt(jQuery('.lpost').css('marginBottom'));
				Drupal.localGrid.container = jQuery('.main-container .localcenter .views-view-grid');
				var gutter = Drupal.localGrid.gutter;
				Drupal.localGrid.container.imagesLoaded( function() {
					Drupal.localGrid.container.masonry({
						gutter: gutter,
						itemSelector: '.lpost',
						columnWidth: '.lpost',
						horizontalOrder: true
					});
				});
			}
			/*
			$('.center-local-search .col').each(function() { 
				var cl = $(this).children('.flag-address.state-space').children('.flag-address');
				$(cl).each(function() { 
					if ($(this).children('.telephone-email').length > 0){
						var cityName = $(this).children('.telephone-email').text();
						var trimCity = cityName.slice(0,-1);
						var remBlankChrecter = trimCity.replace(/\s+/g, '');
						var CityNames = remBlankChrecter.toLowerCase();
						var getID = $(this).children('.telephone-email').attr('id', CityNames);	
						$('#localcentersearchbutton').on('click', function(e) {
							var searchval = document.getElementById('localcentersearch').value;
							if( searchval == remBlankChrecter){
								$(this).addClass('DDDD');
							}
						});
					}
				});
			});
			*/
			if($('.testi-dec').length <= 1) {
			  $(".car-control-left").css("display", "none");
			  $(".car-control-right").css("display", "none");
			}
			/* WC-1890 */
			if($('.carousel-inner .item').length <= 1) {
			  $(".left.carousel-control").css("display", "none");
			  $(".right.carousel-control").css("display", "none");
			}
			if($('.carousel.flickity-enabled.is-draggable .flickity-slider .carousel-cell').length <= 1) {
			  $(".flickity-prev-next-button.previous").css("display", "none");
			  $(".flickity-prev-next-button.next").css("display", "none");
			  $(".flickity-page-dots").css("display", "none");
			}
			if($('.isha-poem-img-div .field--item img').length <= 0) {
			  $(".isha-poem-img-div").addClass("no-shadow");
			}
			if ($('#cityCetersList').length > 0){
				var countryName = $('#views-bootstrap-regiona-centers-block-3 .col-sm-4').text();
				$('.c-name').text(countryName);
			}
			var textEmpty = $('#views-bootstrap-centers-inner-grid-block-2 .btn-isha-centers2 a').text();
			if(textEmpty == ''){
				$('#views-bootstrap-centers-inner-grid-block-2 .btn-isha-centers2').css('display', 'none');
			}
			$('#views-bootstrap-consecrated-spaces-inner-grid-block-3 .row').each(function() { 
				var cls = $(this).children('.col').children('.img-pattern-dhyanlinga-alter').children('.dhyalalinga-construction').children('.my-custom-slider').children('.carousel-inner').children('.item');
				$(cls).each(function() { 
					$(this).parent().find(':first-child').addClass('active');
					$(this).children('img').removeClass('active');
				});
			});
			$('#localcentersearchbutton').on('click', function(e) {
				e.preventDefault();
				$(document).off("scroll");
				var currLink = $(this);
				$('a.cssticky').each(function() {
					$(this).removeClass('active');
				})
				var searchval = document.getElementById('localcentersearch').value;
				
				currLink.addClass('active');
				var divId = "#"+searchval.toLowerCase().replace(" ", "");
				var target = divId;
				$("html, body").animate({scrollTop: $(target).offset().top}, 'swing', function() {
					$(document).on("scroll", onScroll2);
				});
			});
			//Model PopUp 
			$('.modal-dialog.modal-lg').parent('.registration-model-window').addClass('registration-width');
			$('.modal-backdrop').click(function(e) {
				$('.close-svg').click();
			});
		}
	};
})(jQuery, Drupal);
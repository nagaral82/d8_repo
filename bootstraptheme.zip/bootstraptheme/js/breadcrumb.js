(function ($, Drupal) {
    "use strict";
    Drupal.behaviors.breadcrumbOptions = {
        attach: function (context) {
			var mainUrl = document.URL;
			$('body ol.breadcrumb li').each(function() { 
				var getTexts = $(this).text();
				var trimTexts = $.trim(getTexts);
				if(trimTexts == 'In' || trimTexts == 'Global' || trimTexts == 'Us' ||  trimTexts == 'Usa' || trimTexts == 'Uk' || trimTexts == 'En' || trimTexts == 'Ml' || trimTexts == 'Hi' || trimTexts == 'Ta' || trimTexts == 'Te' || trimTexts == 'Ru' || trimTexts == 'Mr' || trimTexts == 'Kn' || trimTexts =='Type'){
					$(this).hide();
				}
			});
			
			/*** My Profile Page***/
			if ($('.myisha-form').length > 0){
				var SplitMainUrl = mainUrl.split("/");
				var myAcount = SplitMainUrl[5];
				var myBookmark = SplitMainUrl[6];
				$( "ol.breadcrumb li:nth-child(4)" ).replaceWith( "<li itemprop='itemListElement' itemscope='' itemtype='http://schema.org/ListItem'><a href='/in/en/my-account/profile'>My Account</a></li>" );
				if(myAcount =='my-account' && myBookmark =='my-bookmark'){
					$('body').mouseover(function(){
						$("ol.breadcrumb li:last").text('profile');
					});
				}
				
			}

			bredcumpTitle();
			if ($('.page-node-type-isha-posts').length > 0 || $('.page-node-type-isha-podcasts').length > 0 || $('.page-node-type-isha-poetry').length > 0 || $('.page-node-type-isha-videos').length > 0 || $('.page-node-type-isha-quotes').length > 0 || $('.page-node-type-isha-sadhguru-spot').length > 0) {
				$('body ol.breadcrumb li').each(function() {
					var SplitMainUrl = mainUrl.split("/");
					var cCode = SplitMainUrl[3];
					console.log(cCode);
					var getText = $(this).text();
					var trimText = $.trim(getText);
					var baseUrl = drupalSettings.path.baseUrl;
					if(trimText == 'En' || trimText == 'Ml' || trimText == 'Hi' || trimText == 'Ta' || trimText == 'Te' || trimText == 'Ru' || trimText == 'Mr' || trimText == 'Kn'){
						$(this).hide();
						$(this).addClass('ln-name');
					}
					var getLang = $('.ln-name').text();
					var trimLang = $.trim(getLang);
					if($('.ln-name').length > 0){
						var code = trimLang.toLowerCase();
						var LCode = code+'/';
						//var langCode = trimLang.toLowerCase();
						//var langCode = '&langcode='+code;
					}
					if($('.page-node-type-isha-quotes').length > 0){
						var ctURL = baseUrl+cCode+'/'+LCode+'wisdom/type/quotes';
					}else if($('.page-node-type-isha-sadhguru-spot').length > 0){
						var ctURL = baseUrl+cCode+'/'+LCode+'wisdom-intermediate/sadhguru-spot';
					}else if($('.page-node-type-isha-posts').length > 0){
						var ctURL = baseUrl+cCode+'/'+LCode+'wisdom-intermediate/article';
					}else if($('.page-node-type-isha-podcasts').length > 0){
						var ctURL = baseUrl+cCode+'/'+LCode+'wisdom-intermediate/audio';
					}else if($('.page-node-type-isha-poetry').length > 0){
						var ctURL = baseUrl+cCode+'/'+LCode+'wisdom-intermediate/poem';
					}else if($('.page-node-type-isha-videos').length > 0){
						var ctURL = baseUrl+cCode+'/'+LCode+'wisdom-intermediate/video';
					}
					if(trimText =='Wisdom'){
						$(this).html('<a href="'+URLWishdom+'">'+getText+"</a>");
					}
					if(trimText =='Poem' || trimText =='Sadhguru spot' || trimText =='Article' || trimText =='Video' || trimText =='Audio'|| trimText =='Quotes'){
						$(this).html('<a href="'+ctURL+'">'+'DDD'+"</a>");
					}	
					if(trimText =='Yoga&Meditation'){
						jQuery(this).html('<a href="'+ctURL+'">'+'Video'+"</a>");
					}
				});
			}		
			/*******For Taxonomy Pages*****/
			if($('.main-container').length > 0 || $('.children-program').length > 0 || $('.centres-program').length > 0 || $('.beginners').length > 0 || $('.chit-shakti-page').length > 0 || $('.isha-5min-page').length > 0 || $('.isha-inner-engg-page').length > 0 || $('.hatha-yoga-page').length > 0 || $('.events-page').length > 0 || $('.isha-bsp-page').length > 0){
				bredcumpTitle();
				var secHref = $('ol.breadcrumb li:nth-child(2) a').attr('href');
				if(secHref != null){
					var secName = secHref.split("/");
					var taxoSecName = secName[1].split("-");
					if(taxoSecName[0] !=null){
						var taxoSecfirstName = taxoSecName[0];
					}
					if( taxoSecName[1] !=null){
						var taxoSecSecName = taxoSecName[1];
					}else{
						var taxoSecSecName = '';
					}
					var taxoSecParentName = taxoSecfirstName+' '+taxoSecSecName;
					$('ol.breadcrumb li:nth-child(2) a').text(taxoSecParentName);
				}
				var thirdHref = $('ol.breadcrumb li:nth-child(3) a').attr('href');
				if(thirdHref != null){
					var thirdName = thirdHref.split("/");
					var taxoName = thirdName[2].split("-");
					if(taxoName[0] !=null){
						var thirdfirstName = taxoName[0];
					}
					if( taxoName[1] !=null){
						var thirdSecName = taxoName[1];
					}else{
						var thirdSecName = '';
					}
					var taxoParentName = thirdfirstName+' '+thirdSecName;
					$('ol.breadcrumb li:nth-child(3) a').text(taxoParentName);
				}
				var fourthHref = $('ol.breadcrumb li:nth-child(4) a').attr('href');
				if(fourthHref != null){
					var fourthName = fourthHref.split("/");
					var taxoNameFour = fourthName[3].split("-");
					if(taxoNameFour[0] !=null){
						var fourfirstName = taxoNameFour[0];
					}
					if( taxoNameFour[1] !=null){
						var fourSecName = taxoNameFour[1];
					}else{
						var fourSecName = '';
					}
					var taxofFourParentName = fourfirstName+' '+fourSecName;
					$('ol.breadcrumb li:nth-child(4) a').text(taxofFourParentName);
				}

				var fiveHref = $('ol.breadcrumb li:nth-child(5) a').attr('href');
				if(fiveHref != null){
					var fiveName = fiveHref.split("/");
					var taxoNamefive = fiveName[4].split("-");
					if(taxoNamefive[0] !=null){
						var fivefirstName = taxoNamefive[0];
					}
					if( taxoNamefive[1] !=null){
						var fiveSecName = taxoNamefive[1];
					}else{
						var fiveSecName = '';
					}
					if( taxoNamefive[2] !=null){
						var fiveThirdName = taxoNamefive[2];
					}else{
						var fiveThirdName = '';
					}
					if( taxoNamefive[3] !=null){
						var fiveFourName = taxoNamefive[3];
					}else{
						var fiveFourName = '';
					}
					if( taxoNamefive[4] !=null){
						var fiveFiveName = taxoNamefive[4];
					}else{
						var fiveFiveName = '';
					}
					var taxofFiveParentName = fivefirstName+' '+fiveSecName+' '+fiveThirdName+' '+fiveFourName+' '+fiveFiveName;
					$('ol.breadcrumb li:nth-child(5) a').text(taxofFiveParentName);
				}
				if ($('.page-node-type-isha-quotes').length > 0) {
					var fourthHref = $('ol.breadcrumb li:nth-child(5) a').text('Quotes');
				}
				var sixHref = $('ol.breadcrumb li:nth-child(6) a').attr('href');
				//alert(sixHref);
				if(sixHref != null){
					var sixName = sixHref.split("/");
					var taxoNamesix = sixName[5].split("-");
					if(taxoNamesix[0] !=null){
						var sixfirstName = taxoNamesix[0];
					}
					if( taxoNamesix[1] !=null){
						var sixSecName = taxoNamesix[1];
					}else{
						var sixSecName = '';
					}
					if( taxoNamesix[2] !=null){
						var sixThirdName = taxoNamesix[2];
					}else{
						var sixThirdName = '';
					}
					if( taxoNamesix[3] !=null){
						var sixFourName = taxoNamesix[3];
					}else{
						var sixFourName = '';
					}
					if( taxoNamesix[4] !=null){
						var sixFiveName = taxoNamesix[4];
					}else{
						var sixFiveName = '';
					}
					var taxofsixParentName = sixfirstName+' '+sixSecName+' '+sixThirdName+' '+sixFourName+' '+sixFiveName;
					$('ol.breadcrumb li:nth-child(6) a').text(taxofsixParentName);
				}

			}
			if ($('.isha-landing-main-content.wisdom-landing-page').length > 0){
				var wisTesxt = $('ol.breadcrumb li:nth-child(4) a').text();
				var wisTrim = $.trim(wisTesxt); 
				if(wisTrim =='wisdom' || wisTrim =='Wisdom Home Page'){
					$('ol.breadcrumb li:nth-child(4)').hide();
				}
			}
			if ($('.isha-landing-main-content.wisdom-landing-page').length > 0) {
                var webText = 'Wisdom';
                $("ol.breadcrumb li:last").text(webText);
            }
			if ($('.isha-wisdom-landing-page.blog-landing-page').length > 0) {
                var webText = 'Blog';
                $("ol.breadcrumb li:last").text(webText);
            }
			if ($('#cityCetersList').length > 0){
				var countryName = $('#views-bootstrap-regiona-centers-block-3 .col-sm-4').text();
				$('ol.breadcrumb li:last').text(countryName);
			}
			if($('.meet-sadhguru-main').length > 0){
					var getTermTitle = $('#meet-sadhguru .isha-rc-home-title .isha-rc-home-title').text();
					$('ol.breadcrumb li:last').text(getTermTitle);
			}
			function bredcumpTitle(){				
				var urlStr = document.URL;
				var lastStr = urlStr.substring(urlStr.lastIndexOf("/") + 1, urlStr.length);
				//alert(lastStr);
				var queryParse = lastStr.split("?");
				var titleParse = queryParse[0].split("-");
				if(titleParse[0] !=null){
					var titleFirst = titleParse[0];
				}
				if( titleParse[1] !=null){
					var titleSec = titleParse[1];
				}else{
					var titleSec = '';
				}
				if( titleParse[2] !=null){
					var titlethird = titleParse[2];
				}else{
					var titlethird = '';
				}
				if( titleParse[3] !=null){
					var titleFourth = titleParse[3];
				}else{
					var titleFourth = '';
				}
			    if ($('.page-node-type-isha-videos').length > 0) {
					var getTermTitle = $('.page-node-type-isha-videos .isha-video-title').text();
				}else if ($('.page-node-type-isha-sadhguru-spot').length > 0) {
					var getTermTitle = $('.page-node-type-isha-sadhguru-spot .isha-article-title').text();
				}else if ($('.page-node-type-isha-quotes').length > 0) {
					var getTermTitle = $('.isha-daily-mystic-quote-title').text();
				}else if($('.page-node-type-isha-posts').length > 0){
					var getTermTitle = $('.page-node-type-isha-posts .isha-article-title').text();
				}else if($('.page-node-type-isha-podcasts').length > 0){
					var getTermTitle = $('page-node-type-isha-podcasts .isha-podcast-title ').text();
				}else if($('.isha-mystic-page.sadhguru-landing').length > 0){
					var getTermTitle = $('.isha-sadhguru-top .yoga-page-banner-title').text();
				}else if($('.page-node-type-isha-poetry').length > 0){
					var getTermTitle = $('.page-node-type-isha-poetry .isha-poem-title').text();
				}else if($('.page-node-type-isha-sadhguru').length > 0){
					var getTermTitle = $('.page-node-type-isha-sadhguru .isha-article-title').text();
				}else{
					var getTermTitle = titleFirst+' '+titleSec+' '+titlethird+' '+titleFourth;	
				}
				if(getTermTitle != ''){
						$('ol.breadcrumb li:last').text(getTermTitle);
				}
			}
			// For Add new comment
			if ($('.comment-reply-dlt').length > 0) {
				$('ol.breadcrumb li:nth-child(4)').hide();
				$('ol.breadcrumb li:nth-child(5)').hide();
				$('ol.breadcrumb li:nth-child(6)').hide();
				$('ol.breadcrumb li:nth-child(7)').hide();
				$('ol.breadcrumb li:nth-child(8)').hide(); 
				 $("ol.breadcrumb li:last").text('Reply Comment');
			}
			if ($('.program-registration-success').length > 0) {
                $('ol.breadcrumb li:nth-child(2)').hide();
                $('ol.breadcrumb li:nth-child(3)').hide();
                $('ol.breadcrumb li:nth-child(4)').hide();
                $('ol.breadcrumb li:nth-child(5)').hide();
                $('ol.breadcrumb li:nth-child(6)').hide();
				$('ol.breadcrumb li:nth-child(7)').hide();
                var webText = 'Program Registration';
                $("ol.breadcrumb li:last").text(webText);
            }
			/******End Breadcrumb*******/
			var getNumber = $('.comments-head-container span.comment-count').text();
			if ($('.comments-head-container span.comment-count').is(':empty')){
				$('.comments-head-container span.comment-count').text('0');
			}else{
				$('.comments-head-container span.comment-count').text(getNumber);
			}
			/******Add body link in wishdom page********/
			if($('.block-views-blockwisdom-grid-view-block-8').length > 0) {
				bodyLink();
			}
			$(".block-views-blockwisdom-grid-view-block-8 ul.js-pager__items li a").click(function(){
				bodyLink()
			});
			$(".block-views-blockwisdom-grid-view-block-8 .views-exposed-form .form-item .select-wrapper select option").click(function(){
				bodyLink()
			});
			function bodyLink(){
				if($('.block-views-blockwisdom-grid-view-block-8').length > 0) {
					$('.block-views-blockwisdom-grid-view-block-8 .col').each(function() { 
						var titleHref = $(this).children('.cards').children('.isha-card-podcast-title').children('a').attr('href');
						var titleHrefQuote = $(this).children('.quote-cards').children('.isha-rp-social').children('.pull-left').children('a').attr('href');
						$(this).children('.quote-cards').children('.margin-top-n-btm.content').children('a').attr("href", titleHrefQuote);
						$(this).children('.cards').children('.isha-rp-desc').children('a').attr("href", titleHref);
						$(this).children('.cards').children('.isha-rp-desc').children('a').attr("href", titleHref);
						$(this).children('.cards').children('a.img-link').attr("href", titleHref);
					});
				}
			}
			$('#views-bootstrap-wisdom-grid-view-block-12 .col').each(function() { 
				var titleHref = $(this).children('.cards').children('.isha-card-podcast-title').children('a').attr('href');
				$(this).children('.cards').children('a.img-link').attr("href", titleHref);
			});
			$('#views-bootstrap-wisdom-grid-view-block-9 .col').each(function() { 
				var titleHref = $(this).children('.cards').children('.isha-card-podcast-title').children('a').attr('href');
				$(this).children('.cards').children('a.img-link').attr("href", titleHref);
			});
			$('#comment-form').on('keydown', '#edit-comment-body-0-value', function(e) {
				if( e.which === 32 && this.value === '' ) {
					return false;
				}         
			});
			jQuery('.main-container').on('click', function(e) {
				jQuery(".isha-header #block-ishanavigation ul#superfish-ishanav li.menuparent ul").css('display', 'none');
			});
			
			// Removing "content type" breadcrumb in "Wisdom" detail pages
			if ($('.page-node-type-isha-posts').length > 0 || $('.page-node-type-isha-podcasts').length > 0 || $('.page-node-type-isha-poetry').length > 0 || $('.page-node-type-isha-videos').length > 0 || $('.page-node-type-isha-quotes').length > 0 || $('.page-node-type-isha-sadhguru-spot').length > 0) {
				$('ol.breadcrumb li:nth-child(5)').hide();
			}
			
        }
    };
})(jQuery, Drupal);
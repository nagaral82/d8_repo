(function ($, Drupal) {
  "use strict";
  
  Drupal.behaviors.volunteerPages = {
    attach: function (context) {
      var faq_block = $('.isha-volunteer-page section[class*=block-views-blockcategories-faq-]');
      var title = $('.block-title', faq_block);
      
      if (!$(title).has('span').length) {
        $(title).append('<span class="glyphicon glyphicon-menu-down"></span>');
      
        $(faq_block).on('click','.block-title', function(e) {
          if ($('.glyphicon-menu-down').length) {
            $('.form-group', faq_block).show();
            $(this)
              .find('.glyphicon')
              .removeClass('glyphicon-menu-down')
              .addClass('glyphicon-menu-up');
          }
          else {         
            $('.form-group', faq_block).hide();
            $(this)
              .find('.glyphicon')
              .removeClass('glyphicon-menu-up')
              .addClass('glyphicon-menu-down');
          }
        });
      }      
    }      
  };
})(jQuery, Drupal);
(function ($, Drupal) {
  "use strict";
  /**
   * Provide vertical tab summaries for Bootstrap settings.
   */
  /*Drupal.behaviors.wisdomAudioStyles = {
    attach: function (context) {
        $('.main-container', context).once('wisdomAudioStyles').each(function() {
            var music = document.getElementsByTagName('audio')[0]; // id for audio element
            //music.style.display = 'none';
            var duration = music.duration; // Duration of audio clip, calculated here for embedding purposes
            var pButton = document.getElementById('pButton'); // play button
            var playhead = document.getElementById('playhead'); // playhead
            var timeline = document.getElementById('timeline'); // timeline
            // timeline width adjusted for playhead
            var timelineWidth = timeline.offsetWidth - playhead.offsetWidth;

            // play button event listenter
            pButton.addEventListener("click", play);

            // timeupdate event listener
            music.addEventListener("timeupdate", timeUpdate, false);

            // makes timeline clickable
            timeline.addEventListener("click", function(event) {
                moveplayhead(event);
                music.currentTime = duration * clickPercent(event);
            }, false);

            // returns click as decimal (.77) of the total timelineWidth
            function clickPercent(event) {
                return (event.clientX - getPosition(timeline)) / timelineWidth;
            }

            // makes playhead draggable
            playhead.addEventListener('mousedown', mouseDown, false);
            window.addEventListener('mouseup', mouseUp, false);

            // Boolean value so that audio position is updated only when the playhead is released
            var onplayhead = false;

            // mouseDown EventListener
            function mouseDown() {
                onplayhead = true;
                window.addEventListener('mousemove', moveplayhead, true);
                music.removeEventListener('timeupdate', timeUpdate, false);
            }

            // mouseUp EventListener
            // getting input from all mouse clicks
            function mouseUp(event) {
                if (onplayhead == true) {
                    moveplayhead(event);
                    window.removeEventListener('mousemove', moveplayhead, true);
                    // change current time
                    music.currentTime = duration * clickPercent(event);
                    music.addEventListener('timeupdate', timeUpdate, false);
                }
                onplayhead = false;
            }
            // mousemove EventListener
            // Moves playhead as user drags
            function moveplayhead(event) {
                var newMargLeft = event.clientX - getPosition(timeline);

                if (newMargLeft >= 0 && newMargLeft <= timelineWidth) {
                    playhead.style.marginLeft = newMargLeft + "px";
                }
                if (newMargLeft < 0) {
                    playhead.style.marginLeft = "0px";
                }
                if (newMargLeft > timelineWidth) {
                    playhead.style.marginLeft = timelineWidth + "px";
                }
            }

            // timeUpdate
            // Synchronizes playhead position with current point in audio
            function timeUpdate() {
                var playPercent = timelineWidth * (music.currentTime / duration);
                playhead.style.marginLeft = playPercent + "px";
                if (music.currentTime == duration) {
                    pButton.className = "";
                    pButton.className = "play";
                }
            }

            //Play and Pause
            function play() {
                // start music
                if (music.paused) {
                    music.play();
                    //var currentTime = setInterval(music.currentTime, 1000);
                    var myVar = setInterval(myTimer, 1000);

                    function myTimer() {
                        var remainingTime = music.duration - music.currentTime;
                        var minutes = Math.floor(remainingTime / 60);
                        var seconds = (remainingTime % 60).toFixed(0);
                        document.getElementById('musDuration').innerHTML = '-' + (minutes + ":" + (seconds < 10 ? '0' : '') + seconds);
                    }
                    // remove play, add pause
                    pButton.className = "";
                    pButton.className = "pause";
                } else { // pause music
                    music.pause();
                    // remove pause, add play
                    pButton.className = "";
                    pButton.className = "play";
                }
            }

            // Gets audio file duration
            music.addEventListener("canplaythrough", function() {
                duration = music.duration;
                //console.log(duration);
                var minutes = Math.floor(duration / 60);
                var seconds = (duration % 60).toFixed(0);
                document.getElementById('musDuration').innerHTML = minutes + ":" + (seconds < 10 ? '0' : '') + seconds;
            }, false);

            // getPosition
            // Returns elements left position relative to top-left of viewport
            function getPosition(el) {
                return el.getBoundingClientRect().left;
            }
        });
        
    }
  };*/
  
  Drupal.behaviors.wisdomAudioStyles = {
		    attach: function (context) {
		        $('.main-container', context).once('wisdomAudioStyles').each(function() {
		            $( ".audioplayer" ).each(function( index ) {
		            	var music = $(this).find('audio'); // id for audio element
		            	var duration = music[0].duration; // Duration of audio clip, calculated here for embedding purposes
		            	var pButton = $(this).find('.pButton'); // play button
			            var playhead = $(this).find('.playhead'); // playhead
			            var timeline = $(this).find('.timeline'); // timeline
			            var musDuration = $(this).find('.musDuration');
			            // timeline width adjusted for playhead
			            var timelineWidth = timeline.outerWidth() - playhead.outerWidth();

			            // play button event listenter
			            //Play and Pause
			            pButton.on('click', function(event){
			                // start music
			                if (music[0].paused) {
			            		music[0].play();
			                    var myVar = setInterval(myTimer, 1000);

			                    function myTimer() {
			                        var remainingTime = music[0].duration - music[0].currentTime;
			                        var minutes = Math.floor(remainingTime / 60);
			                        var seconds = (remainingTime % 60).toFixed(0);
			                        musDuration.html('-' + (minutes + ":" + (seconds < 10 ? '0' : '') + seconds));
			                    }
			                    // remove play, add pause
			                    pButton.removeClass("play");
			                    pButton.addClass("pause");
			                } else { // pause music
			                    music[0].pause();
			                    // remove pause, add play
			                    pButton.removeClass("pause");
			                    pButton.addClass("play");
			                }
			            });

			            // timeupdate event listener
			            music.bind("timeupdate", timeUpdate);
			            	
			            // makes timeline clickable
			            timeline.on("click", function(event) {
			                moveplayhead(event);
			                music[0].currentTime = duration * clickPercent(event);
			            });

			            // makes playhead draggable
			            playhead.bind('mousedown', mouseDown);
			            window.addEventListener('mouseup', mouseUp, false);
	
			            // Boolean value so that audio position is updated only when the playhead is released
			            var onplayhead = false;

			            // Gets audio file duration
			            music.on("canplaythrough", function() {
			                duration = music[0].duration;
			                var minutes = Math.floor(duration / 60);
			                var seconds = (duration % 60).toFixed(0);
			                musDuration.html(minutes + ":" + (seconds < 10 ? '0' : '') + seconds);
			            });
			            
			         // returns click as decimal (.77) of the total timelineWidth
			            function clickPercent(event) {
			                return (event.clientX - getPosition(timeline)) / timelineWidth;
			            }
			            
			            // getPosition
			            // Returns elements left position relative to top-left of viewport
			            function getPosition(el) {
			            	return el.offset().left;
			            }
			            
			            // timeUpdate
			            // Synchronizes playhead position with current point in audio
			            function timeUpdate() {
			                var playPercent = timelineWidth * (music[0].currentTime / duration);
			                playhead.css('margin-left', playPercent + "px");
			                if (music[0].currentTime == duration) {
			                    pButton.removeClass("pause");
			                    pButton.addClass("play");
			                }
			            }
			            
			            // mousemove EventListener
			            // Moves playhead as user drags
			            function moveplayhead(event) {
			                var newMargLeft = event.clientX - getPosition(timeline);

			                if (newMargLeft >= 0 && newMargLeft <= timelineWidth) {
			                	playhead.css('margin-left', newMargLeft + "px");
			                }
			                if (newMargLeft < 0) {
			                	playhead.css('margin-left', "0px");
			                }
			                if (newMargLeft > timelineWidth) {
			                    playhead.css('margin-left', timelineWidth + "px");
			                }
			            }
			            
			            // mouseDown EventListener
			            function mouseDown() {
			                onplayhead = true;
			                window.addEventListener('mousemove', moveplayhead, true);
			                music.unbind('timeupdate', timeUpdate);
			            }

			            // mouseUp EventListener
			            // getting input from all mouse clicks
			            function mouseUp(event) {
			                if (onplayhead == true) {
			                    moveplayhead(event);
			                    window.removeEventListener('mousemove', moveplayhead, true);
			                    // change current time
			                    music[0].currentTime = duration * clickPercent(event);
			                    music.bind('timeupdate', timeUpdate);
			                }
			                onplayhead = false;
			            }
		            });
		        });
		    }
		  };
})(jQuery, Drupal);

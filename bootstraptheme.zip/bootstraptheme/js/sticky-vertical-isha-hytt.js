function onScroll2(event) {
    var scrollPos = jQuery(document).scrollTop() - 600;
    jQuery('#left-menu-center-hytt a').each(function() {
        var currLink = jQuery(this);
        //var divId = "#"+currLink.attr("href").split("#")[1];       
        var divId = "#" + this.href.substr(this.href.lastIndexOf('/') + 1);
        console.log(divId);
        var refElement = jQuery(divId);
        //alert(divId);
        if (jQuery(divId).length) {
            if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
                jQuery('#left-menu-center-hytt li.active').removeClass('active');
                jQuery(currLink).parent().addClass('active');
                jQuery('#left-menu-center-hytt ul li.active a').removeClass("active");
                currLink.addClass("active");
                history.pushState({}, null, currLink.attr("href"));
            } else {
                currLink.removeClass("active");
            }
        }
    });
}

function scrollToPositionOnPageLoadHytt() {
    var currentHref = window.location.href;
    var divId = "#" + currentHref.substr(currentHref.lastIndexOf('/') + 1);
    if (jQuery(divId).length) {
        if (jQuery('#left-menu-center-hytt').is(':visible')) {
            jQuery("html, body").animate({ scrollTop: jQuery(divId).offset().top }, 'swing', function() {
                jQuery(document).on("scroll", onScroll2);
            });
        } else if (jQuery('.mobile-different-view').is(':visible')) {
            var accordionHeader = jQuery(divId).prev()
            jQuery(divId).slideDown(300);
            accordionHeader.children().children().children(".menu-arrow-down").css('display', 'none');
            accordionHeader.children().children().children(".menu-arrow-up").css('display', 'inline-block');
            /*jQuery('html, body').animate({
		        scrollTop: jQuery(divId).offset().top
		    }, 2000);*/
            var offTop = jQuery(divId).offset().top - 60;
            jQuery('html, body').scrollTop(offTop);
        }

    }
}

jQuery(document).ready(function() {
    //scroll to sub-section on page load
    scrollToPositionOnPageLoadHytt();
	/*
	 * To support back button to go previous page
	 */
	window.onpopstate = function() {
	  var referrer =  document.referrer;
	  window.location = referrer;
	}

    jQuery(document).on("scroll", onScroll2);

    if (jQuery(".responsive-tabs")[0]) {
        jQuery('.responsive-tabs').responsiveTabs({
            accordionOn: ['xs']
        });
    } else {
        console.log("No Responsive tabs used");
    }
    /*******DropDown*********/
    jQuery(".menu-arrow-down").css('display', 'inline-block');
    jQuery(".menu-arrow-up").css('display', 'none');
    jQuery(".isha-toggle-submenu-header").click(function() {
        if (jQuery('.isha-toggle-submenu-info').is(':visible')) {
            jQuery(".isha-toggle-submenu-info").slideUp(300);
            jQuery(".menu-arrow-down").css('display', 'inline-block');
            jQuery(".menu-arrow-up").css('display', 'none');
        }
        if (jQuery(this).next(".isha-toggle-submenu-info").is(':visible')) {
            jQuery(this).next(".isha-toggle-submenu-info").slideUp(300);
            jQuery(this).children().children().children(".menu-arrow-down").css('display', 'inline-block');
            jQuery(this).children().children().children(".menu-arrow-up").css('display', 'none');
        } else {
            jQuery(this).next(".isha-toggle-submenu-info").slideDown(300);
            jQuery(this).children().children().children(".menu-arrow-down").css('display', 'none');
            jQuery(this).children().children().children(".menu-arrow-up").css('display', 'inline-block');
             divOffset = jQuery(this).offset().top;
             divHeight = jQuery(this).height();
             viewportHeight = jQuery(window).height();
            if (((divOffset + divHeight) - (viewportHeight)) < viewportHeight) {
                // jQuery('body, html').animate({
                //     scrollTop: divOffset
                // });
                window.scrollTo(0, divOffset)
            } else if ((navigator.userAgent.match(/(iPod|iPhone|iPad|Android)/g))) {
                var elemt = jQuery(this).prev(".isha-toggle-submenu-info").offset().top;
                if (window.innerHeight < window.innerWidth) {
                    window.scrollTo(0, -elemt);
                } else {
                    var toGo = divOffset + viewportHeight - elemt;
                    window.scrollTo(0, toGo);
                }
            } else {
                jQuery('body, html').animate({
                    //scrollTop: jQuery(this).prev(".isha-toggle-submenu-info").offset().top,
                    scrollTop: jQuery(this).offset().top
                }, 10);
            }
			//console.log(divOffset);
           // window.scrollTo(0, divOffset);
            //window.scrollTo(jQuery(this).prev(".isha-toggle-submenu-info").offset().top);
        }
    });
    /******End DropDown*********/
    if (jQuery("#ymVerticalEnable")) {
        var enableVerticalMenu = jQuery("#ymVerticalEnable").val();
        if (enableVerticalMenu == "yes") {
            var divId = "#" + window.location.href.substr(window.location.href.lastIndexOf('/') + 1);
            //console.log(divId)
            if (jQuery(divId).length) {
                $target = jQuery(divId);
                jQuery('html, body').stop().animate({
                    'scrollTop': $target.offset().top + 2
                }, 100, 'swing', function() {
                    jQuery(document).on("scroll", onScroll2);
                });
            }
        }
    }

    jQuery('#left-menu-center-hytt a').on('click', function(e) {
        e.preventDefault();
        jQuery(document).off("scroll");
        var currLink = jQuery(this);
        jQuery('#left-menu-center-hytt li.active').removeClass('active');
        jQuery(currLink).parent().addClass('active');
        jQuery('a.cssticky').each(function() {
            jQuery(this).removeClass('active');
        })
        currLink.addClass('active');
        var divId = "#" + this.href.substr(this.href.lastIndexOf('/') + 1);
        var target = divId;
        history.pushState({}, null, currLink.attr("href"));
        jQuery("html, body").animate({ scrollTop: jQuery(target).offset().top }, 'swing', function() {
            jQuery(document).on("scroll", onScroll2);
        });
    });
    jQuery('.art-row .padding-right-1').on('click', function(e) {
        jQuery('#architecture').animate({ scrollTop: 0 }, 200);
    });
    jQuery('.faq-htc').on('click', function(e) {
        jQuery("html, body").animate({ scrollTop: jQuery('#faqs').offset().top }, 'slow');
    });

});
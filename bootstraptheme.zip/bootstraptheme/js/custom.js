(function($, Drupal) {
    "use strict";
    Drupal.behaviors.generalCustomOptions = {
        attach: function(context) {
            /***** Add Class for Android Device ******/
            if ((navigator.userAgent.match(/(Android)/g))) {
                $('body').addClass('android-device');
            }

            /*if ($(window).width() > 1100) {
                if ($('.domain-IN').length > 0) {
                    $("<li>&nbsp;</li>").insertBefore("li#ishanav-menu-link-contentc28181a2-e352-4cae-82b4-cbd134cc900a--2");
                }
            }*/
            if ($('.isha-download-block').length > 0) {
                $(window).load(function() {
                    $('.responsive-tabs-container ul li:first a.dwl_sec').click();
                });
            }

            $(".rm-hide.read-more-btn").click(function() {
                $("html, body").animate({ scrollTop: $('#top-cl').offset().top }, 'slow');
            });
            if ($('#yoga-landingpg .threecardsblock .block-region-content-top-10 .view-content').length > 0) {
                $('.yoga-landingpg .threecardsblock .block-region-content-top-10').parent('.col-xs-12').addClass('show-div');
            } else {
                $('.yoga-landingpg .threecardsblock .block-region-content-top-10').parent('.col-xs-12').addClass('hide-div');
            }
            $(".see-all-topic .row .col-md-4").each(function() {
                if ($(this).children('.checkbox').children('label').children('input').prop("checked")) {
                    $(this).children('.checkbox').addClass('active-blod');
                }
            });
            //if($(this).prop( "checked"
            if ($('#views-bootstrap-regiona-centers-block-2 .center-hide-div').length > 0) {
                $('#showCityCenters').hide();
            }
            $('.isha-landing-main-content .form-radios label input:checked').parent().addClass("active-radio");
            $('.isha-landing-main-content .form-radios label input').click(function() {
                $('.isha-landing-main-content .form-radios label input:not(:checked)').parent().removeClass("active-radio");
                $('.isha-landing-main-content .form-radios label input:checked').parent().addClass("active-radio");
            });
            var tempHeight = $('.isha-daily-mystic-quote-detail-page .isha-daily-mystic-quote-carousel .quote-cards.quote-table-cell').height();
            $('.isha-daily-mystic-quote-detail-page .isha-daily-mystic-quote-carousel .daily-quote-image.quote-table-cell.quote-img-custom img').css('min-height', tempHeight);
            /** NO link Menu****/
            /* $('#ishanav-menu-link-content57936cbf-6184-4c92-a7f7-713458b0ca6e--2 a').click(function(e){
            	 e.preventDefault();
            })
            $('#ishanav-menu-link-contente6f55ebd-ed2e-4d78-8f08-a133fda29770--2 a').click(function(e){
            	 e.preventDefault();
            })
            $('#ishanav-menu-link-content941034b3-0eb0-4d20-ac65-c48f64ab3242--2 a').click(function(e){
            	 e.preventDefault();
            }) */
            $('#showCityCenters a').click(function(e) {
                e.preventDefault();
            })
            $('#superfish-ishanav li a').each(function() {
                var menuLink = $(this).attr('href');
                var menuHref = menuLink.slice(0, 1);
                console.log(menuHref);
                if (menuHref == '#') {
                    $(this).addClass('disable-link');
                }
            })
            $('.disable-link').click(function(e) {
                e.preventDefault();
            })

            /****Url Change in Program Card******/
            if ($('.block-views-blockupcoming-programs-for-centres-new-block-1').length > 0) {
                var getUrl = window.location;
                var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[0];
                $('.block-views-blockupcoming-programs-for-centres-new-block-1 .col').each(function() {
                    var getChildren = $(this).children('.up-program-popup');
                    $(getChildren).click(function() {
                        var getHref = getChildren.attr('href');
                        var actHref = getHref.substring(1)
                        history.replaceState('data to be passed', 'Title of the page', baseUrl + actHref);
                    });
                });

            }

            if ($('#views-bootstrap-related-programs-block-7').length > 0) {
                $("#views-bootstrap-related-programs-block-7 .row .col").each(function() {
                    var charChangeText = $(this).children('.views-field').children('.field-content').children('a').children('.secondary-cards').children('.img-txt').children('.card-title-block').children('.title').text().substring(0, 35);
                    $(this).children('.views-field').children('.field-content').children('a').children('.secondary-cards').children('.img-txt').children('.card-title-block').children('.title').text(charChangeText);
                });
            }
            if ($('.isha-home-page #twitter-widget-0').length > 0) {
                $(".isha-home-page #twitter-widget-0").attr("scrolling", "yes");
            }
            /**** First letter design caption ***/
            $('.isha-article-desc', context).once('mybehavior').each(function() {
                //alert($('.isha-article-desc .dropcap').length);
                if ($('.isha-article-desc .dropcap').length == 0) {
                    firstLetterGeneration();
                }
                if ($('.isha-article-desc em:contains("Editorâ€™s Note")').length > 0) {
                    applyEditorNoteStyle();
                }
            });

            function firstLetterGeneration() {
                var elem = '.isha-podcast-detail-page .field--type-text-with-summary > p';
                if ($(elem).length) {
                    var singleText = $(elem).first().text().slice(0, 1);
                    var otherText = $(elem).first().html().substring(1);
                    if (singleText != null) {
                        $("#bigtext").html(singleText);
                        $(".dropcap.hide").removeClass('hide').show();
                    }
                    if (otherText != null) {
                        $(elem).first().html(otherText);
                    }
                }
            }

            function applyEditorNoteStyle() {
                var elem = $('.isha-article-desc em:contains("Editorâ€™s Note")');
                elem.find('a').addClass('editor-subs');
                elem.parent().parent().find("div.divider").hide();
                elem.parent().html('<div class="editor-desc"><div class="editor-inner">' + elem.html() + '</div></div>');
            }
            /**** First letter design caption - ends ***/

            $('body', context).once('mybehavior2').each(function() {
                //$(".social-svg-id").click(function(){
                $('body').on('click', '.social-svg-id', function(e) {
                    e.stopPropagation();
                    var kk = $(this).parent().find('.slide-show');
                    $('.slide-show').hide();
                    $(kk).show();
                });

                if ($('.slide-show').length > 0) {
                    $(document).on('click', 'body', function(e) {
                        $('.slide-show').hide();
                    });
                }

                /*$("#leftSlide").click(function(){
                    $(this).parent().find("[id^='views_slideshow_cycle_teaser_']").cycle('prev');
                });
                $("#rightSlide").click(function(){
                    $(this).parent().find("[id^='views_slideshow_cycle_teaser_']").cycle('next');
                });*/

                $(".isha-testimonials-block .carousel-inner > .item:first").addClass('active');

                $('.program-cards-small').bind('contextmenu', function(e) {
                    return false;
                });
                $("#teachers-in-your-area #Find_Teacher li.pager__item .button").click(function() {
                    $("#Find_Teacher").css("clip-path", "polygon(0 0, 100% 0, 100% 100%, 0% 100%)");
                });
                $("#showComments").click(function() {
                    $('.hide-comment').show();
                    $('.show-comment').hide();
                    $(".comments-container").slideToggle('slow');
                });
                //$('#myTab').tabCollapse(); hometopCarousel
                /*$('#contact-message-global-contact-form-form input[type=email]').on('change invalid', function() {
                    var textfield = $(this).get(0);
                    textfield.setCustomValidity('');
                    if (!textfield.validity.valid) {
                        $('.valid-email').css('display', 'none');
                        $('.in-valid-email').css('display', 'inline-block');
                        textfield.setCustomValidity('Looks like your email is invalid.');
                    } else {
                        $('.valid-email').css('display', 'inline-block');
                        $('.in-valid-email').css('display', 'none');
                    }
                });*/

                $("#hideComments").click(function() {
                    $('.show-comment').show();
                    $('.hide-comment').hide();
                    $(".comments-container").slideToggle('slow');
                });

                $(".read-more-btn").click(function() {
                    $(this).parent().parent().find('.complete').slideToggle('slow', function() {
                        if ($(this).parent().parent().find('.complete').css('display') == "block") {
                            $(".rm-show").hide();
                            $(".rm-hide").show();
                        } else {
                            $(".rm-hide").hide();
                            $(".rm-show").show();
                        }
                    });
                });

                $(".btn-hytt-submit").click(function(event) {
                    $(document).find('[data-bef-auto-submit-click]').click();
                    return false;
                });

                $(document).on("click", ".btn-hytt-submit", function() {
                    $(document).find('[data-bef-auto-submit-click]').click();
                });

                $("[name='taddress']").keypress(function(e) {
                    if (e.which == 13) {
                        $(document).find('[data-bef-auto-submit-click]').click();
                        return false;
                    }
                });


            });
            $('#myCarouselDD2 .item:first').addClass('active');
            $('#myCarouselDD3 .item:first').addClass('active');
            $('#myCarouselDD4 .item:first').addClass('active');
            $('#drupal-modal .modal-header').addClass('background-white1 header-diagonal');
            $('#drupal-modal .modal-header button.close span').addClass('close-svg');
            $('#cardsCarousel .item:first').addClass('active');
            $('#videoCarousel .item:last').addClass('left');
            $('#videoCarousel .item:first').addClass('active left');
            if ($('#videoCarousel .item').hasClass('active.left')) {
                $('#videoCarousel .item:first').removeClass('active');
            }
            if ($(window).width() > 767 && $(window).width() < 1024) {
                console.log('Tablet');
                $('#videoCarousel .item').each(function() {
                    // TWO items carousel
                    var next = $(this).next();

                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }
                    next.children(':first-child').clone().appendTo($(this));
                });
                $('#cardsCarousel .item').each(function() {
                    // TWO items carousel
                    var next = $(this).next();

                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }
                    next.children(':first-child').clone().appendTo($(this));
                });
                if ($(".isha-toggle-submenu-info").length > 1) {
                    $(".isha-toggle-submenu-info").css("display", "none")
                    $(".isha-toggle-submenu-info").first().css("display", "block");
                }
            } else if ($(window).width() > 1024) {
                console.log('not tablet');
                if ($('.isha-posts').attr('lang') == 'te') {
                    $(".isha-article-title").css("line-height", "1.20");
                }
                $('#videoCarousel .item').each(function() {
                    // three items carousel
                    var next = $(this).next();
                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }
                    next.children(':first-child').clone().appendTo($(this));

                    if (next.next().length > 0) {
                        next.next().children(':first-child').clone().appendTo($(this));
                    } else {
                        $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
                    }
                });
                $('#cardsCarousel .item').each(function() {
                    // three items carousel
                    var next = $(this).next();
                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }
                    next.children(':first-child').clone().appendTo($(this));

                    if (next.next().length > 0) {
                        next.next().children(':first-child').clone().appendTo($(this));
                    } else {
                        $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
                    }
                });
                $('li.profile-myisha').click(function() {
                    if ($('li.profile-myisha').hasClass('active')) {
                        $('#my-bookmark').css('display', 'none');
                        $('#profile').css('display', 'block');
                    }
                });
                $('li.bookmarks-myisha').click(function() {
                    if ($('li.bookmarks-myisha').hasClass('active')) {
                        $('#my-bookmark').css('display', 'block');
                        $('#profile').css('display', 'none');
                        window.dispatchEvent(new Event('resize'));
                    }
                });

                $('#userLoggedin').click(function() {
                    $('.profile-myisha').click(function() {
                        $('#data-profile').css('display', 'block');
                        setTimeout(function() {
                            $('.block-views-blockmy-bookmarks-block-18').show()
                            $('.block-views-blockmy-bookmarks-block-18').hide()
                        }, 2000);
                    });
                });
                $('#userLoggedin').click(function() {
                    $('.bookmarks-myisha').click(function() {
                        $('.block-views-blockmy-bookmarks-block-18').show();
                        $('#data-profile').hide();
                        window.dispatchEvent(new Event('resize'));
                    });
                });
            }
            $('.block-views-blockman-mission-mystic-tabs-pages-block-7 .views-row').each(function() {
                if ($(this).children('.row').children('.col-lg-6').children('.carousel').children('.carousel-inner').children('.item').length < 2) {
                    $(this).children('.row').children('.col-lg-6').children('.carousel').children('.carousel-indicators').css('display', 'none');
                }
            });

            $('#views-bootstrap-consecrated-spaces-inner-grid-block-3 .row').each(function() {
                if ($(this).children('.col').children('.img-pattern-dhyanlinga-alter').children('.dhyalalinga-construction').children('.my-custom-slider').children('.carousel-inner').children('.item').length < 2) {
                    $(this).children('.col').children('.img-pattern-dhyanlinga-alter').children('.dhyalalinga-construction').children('.my-custom-slider').children('.carousel-indicators').css('display', 'none');
                }
            });
            /**right click disable***/
            $(function() {
                $('#videoCarousel .meet-sadhguru .item .rigister-wrap .btn-isha-register').bind('contextmenu', function(e) {
                    return false;
                });
            });
            /*** Slick carousel pagination ***/
            $('body', context).once('slickbehav').each(function() {
                var $status = jQuery('div .view-upcoming-event-carousel .view-header');
                var $slickElement = jQuery('.slick__slider');
                $slickElement.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
                    //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
                    var i = (currentSlide ? currentSlide : 0) + 1;
                    //$(this).find('.slider_tag span').text(i + ' of ' + slick.slideCount);
                    $status.text(i + ' of ' + slick.slideCount);
                });
            });
            var defTextSadhguru = $('.isha-bsp-specific.isha-sadhguru-landing-block .block-views-blockman-mission-mystic-tabs-pages-block-4 .view-filters ul.multiselect-container li.active').text();
            $('.block-views-blockman-mission-mystic-tabs-pages-block-4 .btn-default').text(defTextSadhguru);
            var defLang = $('#views-exposed-form-wisdom-grid-view-block-8 .form-item-langcode ul.multiselect-container li.active').text();
            $('#views-exposed-form-wisdom-grid-view-block-8 .form-item-langcode button.btn-default span.multiselect-selected-text').text(defLang);
            if ($('.form-item-topic .multiselect-native-select .dropdown-menu li.active').length > 0 || $('.form-item-type .multiselect-native-select .dropdown-menu li.active').length > 0) {
                $('.clear-all').addClass("show-custom");
            }

            var defLangBlog = $('#views-exposed-form-wisdom-grid-view-block-19 .form-item-langcode ul.multiselect-container li.active').text();
            $('#views-exposed-form-wisdom-grid-view-block-19 .form-item-langcode button.btn-default span.multiselect-selected-text').text(defLangBlog);

            if ($('.form-item-topic .multiselect-native-select .dropdown-menu li.active').length > 0 || $('.form-item-type .multiselect-native-select .dropdown-menu li.active').length > 0) {
                $('.clear-all').addClass("show-custom");
            }


            function scrollTOSadhguru() {
                var urlStr = document.URL;
                var lastStr = urlStr.substring(urlStr.lastIndexOf("?") + 1, urlStr.length);
                if (lastStr == 'section=man' || lastStr == 'section=mission' || lastStr == 'section=mystic' || lastStr == 'section=All') {
                    $('body').addClass('man-mystic-mission');
                }
                if ($('body.man-mystic-mission').length > 0) {
                    $("html, body").animate({ scrollTop: $('.isha-bsp-specific.isha-sadhguru-landing-block').offset().top }, 'slow');
                }

            }
            if ($('.meet-sadhguru-main').length > 0) {
                $("html, body").animate({ scrollTop: $('.meet-sadhguru-main #meet-sadhguru').offset().top }, 'slow');
            }

            if ($('.mb-top').length > 0) {
                $(".rm-hide.read-more-btn").click(function() {
                    $(".mb-top").scrollTop();
                });
            }
            //scrollTOSadhguru();
            $(".isha-toggle-submenu-header1").click(function() {
                $(this).addClass('expand');
                var currentClass = $(this).next(".isha-toggle-submenu-info1");
                currentClass.addClass('expand');
                if ($(currentClass).hasClass('expand')) {
                    $(".isha-toggle-submenu-header1").next('.isha-toggle-submenu-info1').removeClass("expand");
                    $(this).next(".isha-toggle-submenu-info1").addClass("expand");
                }
                if ($(this).hasClass('expand')) {
                    $(".isha-toggle-submenu-header1").removeClass("expand");
                    $(this).addClass("expand");
                }
            });
            //menuUrl();
            $('#showCityCenters').click(function() {
                $('#cityCetersList').show();
                $('#cityCetersList').css('margin-top', '-90px');
                $('#showCityCenters').hide();
            });
            $('#closeTheList').click(function() {
                $('#cityCetersList').hide();
                $('#showCityCenters').show();
            });

            var pageMumbaiCenterUrl = window.location.hash;
            if (pageMumbaiCenterUrl == "#viewallcenters") {
                $('#cityCetersList').show();
                $('#cityCetersList').css('margin-top', '-90px');
                $('#showCityCenters').hide();
            }

            var sadhguruText = $('.isha-bsp-specific.isha-sadhguru-landing-block .view-man-mission-mystic-tabs-pages .select-wrapper #edit-section option:selected').text();
            $('.isha-bsp-specific.isha-sadhguru-landing-block .view-man-mission-mystic-tabs-pages .btn-group .multiselect-selected-text').text(sadhguruText);
            //end js  for card slider on iis pageX
            $('.rigister-wrap .btn-isha-register').click(function() {
                $('#drupal-modal .modal-dialog').addClass('modal-lg');
            });


            $('.isha-mystic-page.sadhguru-landing .isha-bsp-specific.isha-sadhguru-landing-block .row .col:even .secondary-cards .img-txt').addClass(' card-with-ribbon');
            $('.isha-media-press-page .tab-pane ul.js-pager__items li a').addClass(' btn btn-isha-custom-rm');
            $('.isha-mystic-page .isha-bsp-specific .block-region-mystic ul.js-pager__items li a').addClass(' btn btn-lg btn-isha-1');
            window.addEventListener("orientationchange", function() {
                // Announce the new orientation number
                // alert(window.orientation);
                if ($(window).width() > 1023) {
                    console.log('tablet landscape oriented ');
                    $('#videoCarousel .item').each(function() {
                        // three items carousel
                        var next = $(this).next();
                        if (!next.length) {
                            next = $(this).siblings(':first');
                        }
                        next.children(':first-child').clone().appendTo($(this));

                        if (next.next().length > 0) {
                            next.next().children(':first-child').clone().appendTo($(this));
                        } else {
                            $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
                        }
                        console.log('looped' + next.length);
                    });
                }
                // $('.isha-toggle-submenu-info').css('display', 'block');
                $('.home-top-carousel').flickity({
                    autoPlay: true,
                    contain: true
                });
                window.dispatchEvent(new Event('resize'));
                if ($(window).width() > 767 && $(window).width() < 1024) {
                    if ($(".isha-toggle-submenu-info").length > 1) {
                        $(".isha-toggle-submenu-info").css("display", "none")
                        $(".isha-toggle-submenu-info").first().css("display", "block");
                    } else {
                        console.log("No isha-toggle-submenu-info class avaiable")
                    }
                } else {
                    $('.isha-toggle-submenu-info').css('display', 'block');
                }
            }, false);
            //plugin bootstrap minus and plus
            //http://jsfiddle.net/laelitenetwork/puJ6G/

            // Selecting number of participant for US

            $('#drupal-modal .modal-dialog').addClass('modal-lg');
            $(".modal-dialog").wrap('<div class="registration-model-window"></div>');
            $('#program_incident_popup .collapse').collapse('hide');
            var programId = drupalSettings.isha_prog_events.program_id;
            var aboutlink = drupalSettings.isha_prog_events.about_link;

            if (aboutlink != 0) {
                $('div.region-content h1.page-header').html('<a href="' + aboutlink + '">' + $('div.region-content h1.page-header').text() + '</a>');
            }


            if ($("#total-number-display").length) {
                $('#register').click(function() {
                    var href = $(this).attr('href') + '&nprt=' + $("#total-number-display").val();
                    $(this).attr('href', href);
                });
            }

            $('.btn-number').click(function(e) {
                e.preventDefault();

                var fieldName = $(this).attr('data-field');
                var type = $(this).attr('data-type');
                var input = $("input[name='" + fieldName + "']");
                var currentVal = parseInt(input.val());

                if (!isNaN(currentVal)) {
                    if (type == 'minus') {
                        if (currentVal > input.attr('min')) {
                            input.val(currentVal - 1).change();
                        }
                        if (parseInt(input.val()) == input.attr('min')) {
                            $(this).attr('disabled', true);
                        }

                    } else if (type == 'plus') {
                        if (currentVal < input.attr('max')) {
                            input.val(currentVal + 1).change();
                        }
                        if (parseInt(input.val()) == input.attr('max')) {
                            $(this).attr('disabled', true);
                        }
                    }
                } else {
                    input.val(0);
                }
            });
            $(".program-cards-small>div.toparea>div.toprow").each(function() {
                if ($(this).text().length > 60) {
                    console.log("PG cards title length --- " + $(this).text().length);
                    $(this).text($(this).text().substring(0, 60));
                } else {
                    console.log("PG cards title length else block--- " + $(this).text().length);
                }
            });
            if ($(window).width() > 767 && $(window).width() < 900) {
                $(".program-cards-small>div.toparea>div.toprow").each(function() {
                    if ($(this).text().length > 47) {
                        console.log("PG cards title length --- " + $(this).text().length);
                        $(this).text($(this).text().substring(0, 47));
                    } else {
                        console.log("PG cards title length else block--- " + $(this).text().length);
                    }
                });
            }
			var mainUrl = document.URL;
            if ($('#my-bookmark').length != 0) {
                if ($(window).width() < 900) {
                    $('#my-bookmark').css('display', 'block');
                    setTimeout(function() {
					if ($('.myisha-form').length > 0){
						var SplitMainUrl = mainUrl.split("/");
						var myAcount = SplitMainUrl[5];
						var myBookmark = SplitMainUrl[6];
						if(myAcount =='my-account' && myBookmark =='my-bookmark'){
							$('#profile').css('display', 'none');
						}
						if(myAcount =='my-account' && myBookmark =='profile'){
							$('#my-bookmark').css('display', 'none');
						}						
					}
                    }, 500);
                }
            }

            $('.input-number').focusin(function() {
                $(this).data('oldValue', $(this).val());
            });
            $('.input-number').change(function() {
                var minValue = parseInt($(this).attr('min'));
                var maxValue = parseInt($(this).attr('max'));
                var valueCurrent = parseInt($(this).val());

                var name = $(this).attr('name');
                if (valueCurrent >= minValue) {
                    $(".btn-number[data-type='minus'][data-field='" + name + "']").removeAttr('disabled')
                } else {
                    alert('Sorry, the minimum value was reached');
                    $(this).val($(this).data('oldValue'));
                }
                if (valueCurrent <= maxValue) {
                    $(".btn-number[data-type='plus'][data-field='" + name + "']").removeAttr('disabled')
                } else {
                    alert('Sorry, the maximum value was reached');
                    $(this).val($(this).data('oldValue'));
                }

            });
            $(".input-number").keydown(function(e) {
                // Allow: backspace, delete, tab, escape, enter and .
                if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
                    // Allow: Ctrl+A
                    (e.keyCode == 65 && e.ctrlKey === true) ||
                    // Allow: home, end, left, right
                    (e.keyCode >= 35 && e.keyCode <= 39)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });

            // <!--Plug-in Initialisation-->
            //Horizontal Tab

            $('#offlinedonation').easyResponsiveTabs({
                type: 'default', //Types: default, vertical, accordion
                width: 'auto', //auto or any width like 600px
                fit: true, // 100% fit in a container
                tabidentify: 'hor_1', // The tab groups identifier
                activate: function(event) { // Callback function if tab is switched
                    var $tab = $(this);
                    var $info = $('#nested-tabInfo');
                    var $name = $('span', $info);
                    $name.text($tab.text());
                    $info.show();
                }
            });



            //validation for ieo leave message form
            $('#contact-message-global-contact-form-form input[type=email]').on('blur', function(e) {
                return validateIEOEmailField();
            });
            $('#contact-message-global-contact-form-form textarea').on('blur', function(e) {
                return validateIEOMessageField();
            });
            $('#contact-message-global-contact-form-form #edit-submit').on('click', function(e) {
                if (validateIEOEmailField() && validateIEOMessageField()) {
                    $('#contact-message-global-contact-form-form').submit();
                    return true;
                }
                return false;
            });
            /*** Program Registration Page Breadcrumb*******/
            if ($('.program-registration-page').length > 0 || $('.path-enquiry').length > 0 || $('.path-program-registration').length > 0) {
                $('ol.breadcrumb li:nth-child(2)').hide();
                $('ol.breadcrumb li:nth-child(3)').hide();
                $('ol.breadcrumb li:nth-child(4)').hide();
                $('ol.breadcrumb li:nth-child(5)').hide();
                $('ol.breadcrumb li:nth-child(6)').hide();
                var webText = 'Program Registration';
                $("ol.breadcrumb li:last").text(webText);
            }
						
            if ($('.webminar-desktop').length > 0) {
                $('ol.breadcrumb li:nth-child(3)').hide();
                $('ol.breadcrumb li:nth-child(2)').hide();
                $('ol.breadcrumb li:nth-child(4)').hide();
                $('ol.breadcrumb li:nth-child(5)').hide();
                var webText = 'Program Registration';
                $("ol.breadcrumb li:last").text(webText);
            }
            if ($('.webminar-iframe').length > 0) {
                var webText = 'Program Registration';
                $("ol.breadcrumb li:last").text(webText);
            }
            if ($('#lightgallery').length != 0) {
                $('#lightgallery').lightGallery();
            }
            // if ($('a.dwl_sec').length > 1) {
            //     $('a.dwl_sec').on('click touch', function() {
            //         window.dispatchEvent(new Event('resize'));
            //     });
            // }

            function validateIEOMessageField() {
                var inputMsgElem = $('#contact-message-global-contact-form-form textarea');
                inputMsgElem.next('.validator').remove();
                var inputMsg = inputMsgElem.val();
                if (inputMsg.trim() == '') {
                    inputMsgElem.after('<span class="validator">Message is required</span>');
                    return false;
                }
                return true;
            }

            function validateIEOEmailField() {
                var inputEmailElem = $('#contact-message-global-contact-form-form input[type=email]');
                inputEmailElem.next('.validator').remove();
                if (inputEmailElem.length) { //to handle admin/anonymous user
                    var inputEmail = inputEmailElem.val();
                    var emailRegx = /[A-Za-z]+[A-Za-z0-9._]+@[A-Za-z]+\.[A-Za-z.]{2,5}$/;
                    if (inputEmail == '') {
                        inputEmailElem.after('<span class="validator">Email is required</span>');
                        return false;
                    } else if (!emailRegx.test(inputEmail)) {
                        inputEmailElem.after('<span class="validator">Check the email address format</span>');
                        return false;
                    }
                }
                return true;
            }


            $("#isha-donation-offline-form #edit-email").on('blur', function(e) {
                return validateDonationEmailField();
            });

            function validateDonationEmailField() {
                $('#isha-donation-offline-form .validator').remove();
                var inputEmailElem = $('#isha-donation-offline-form #edit-email');
                var inputEmail = inputEmailElem.val();
                var emailRegx = /[A-Za-z]+[A-Za-z0-9._]+@[A-Za-z]+\.[A-Za-z.]{2,5}$/;
                if (inputEmail == '') {
                    inputEmailElem.after('<span class="validator">Email is required</span>');
                    return false;
                } else if (!emailRegx.test(inputEmail)) {
                    inputEmailElem.after('<span class="validator">Enter a valid email address</span>');
                    return false;
                }
                return true;
            }
            $("input:checked").css({ "font-color": "red" });
        }
    };
})(jQuery, Drupal);
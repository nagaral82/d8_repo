(function ($, Drupal) {
  /*global jQuery:false */
  /*global Drupal:false */
  "use strict";
 
  /**
   * Provide vertical tab summaries for Bootstrap settings.
   */
  Drupal.behaviors.wisdomFilterOptions = {
    attach: function (context) {
         //var seamless = new Seamless({acceptFrom:['prsdemo.isha.in', 'prs.isha.in', 'www.innerengineering.com', 'dev12.innerengineering.com']});
        if (typeof Seamless === 'function') {
			var seamless = new Seamless({acceptFrom:['prsdemo.isha.in', 'prs.isha.in', 'www.innerengineering.com', 'dev12.innerengineering.com']});
		}
		function triggerSubmit(e) {
            $(this).find('[data-bef-auto-submit-click]').click();
        }
 
        function filterFormSubmit() {
                $(document).find('[data-bef-auto-submit-click]').click();
        }
 
        function ddOptionsRebuild() {
			$("[name='type[]']").multiselect('rebuild');
            $("[name='langcode[]']").multiselect('rebuild');
            $("[name='topic[]']").multiselect('rebuild');
            $("[name='sort_bef_combine']").multiselect('rebuild');
        }
        function generateGridValues() {
            var options = $('option:selected');
            var htmlText = "";
            var optionsMap = $.map(options, function(option) {
                var parentId = option.parentNode.id;
                if(option.value!=" " && option.value!="") {
                    htmlText += "<div class='filter-options "+option.value+"' id='" + option.value + "' parent-id='" + parentId + "'>" + option.text + "<span class='filter-close' data-id='" + option.value + "'><a class='close-link'>X</a></span></div>";
                }
            });
            if(htmlText!=""){
                htmlText += "<div class='filter-options clear-all'><span id='clearAll'><a class='close-link'>Clear All</a></span></div>";
            }
            $(".filter-details").html(htmlText);
        }
 
		function generateQueryStringToUrl(newParamObj = "") {
			var selected = [];
			var actual_q_str = '';
			var newUrl = '';
			var str = window.location.search;
			
			return '';
			var $queryFields = getQueryFields();
			$.each($queryFields, function (key, value) {
				if (value) {
					actual_q_str = getActualQuery('[name="'+key+'"] :selected');
					var q_key = key.replace("[]", "");
					str = replaceQueryParam(q_key, actual_q_str, str);
				}
				else {
					actual_q_str = getActualQuery('[name="'+key+'"]');
					str = replaceQueryParam(key, actual_q_str, str);
				}
			});          

			var qSort = getActualQuery('[name="sort_bef_combine"] :selected');
			if(qSort == " ") {
				qSort = qSort.replace(/\s/g,'');
				str = replaceQueryParam('sort_bef_combine', qSort, str);
			}
			else {
				str = replaceQueryParam('sort_bef_combine', qSort, str);  
				
			}

			if(newParamObj.page && newParamObj.page!='') {
				str = replaceQueryParam('page', newParamObj.page, str);
				
			}

			newUrl = window.location.pathname + str;
			if(newUrl!=''){
				var lastChar = newUrl.slice(-1);
				if((lastChar == "&") || ((lastChar == "?"))) {
					newUrl = newUrl.substring(0, newUrl.length-1);
				}
			}
			history.replaceState('data to be passed', 'Title of the page', newUrl);
		}
                               
		function generateQueryStringToUrl1(newParamObj = "") {
			var selected = [];
			var actual_q_str = '';
			var newUrl = '';
			var str = window.location.search;
			var $queryFields = getQueryFields();
			$.each($queryFields, function (key, value) {
				if (value) {
					actual_q_str = getActualQuery('[name="'+key+'"] :selected');
					var q_key = key.replace("[]", "");
					str = replaceQueryParam(q_key, actual_q_str, str);
				}
				else {
					actual_q_str = getActualQuery('[name="'+key+'"]');
					str = replaceQueryParam(key, actual_q_str, str);
				}
			});          

			var qSort = getActualQuery('[name="sort_bef_combine"] :selected');
			if(qSort == " ") {
				qSort = qSort.replace(/\s/g,'');
				str = replaceQueryParam('sort_bef_combine', qSort, str);
			}
			else {
				str = replaceQueryParam('sort_bef_combine', qSort, str);  
			}

			if(newParamObj.page && newParamObj.page!='') {
				str = replaceQueryParam('page', newParamObj.page, str);
			}

			newUrl = window.location.pathname + str;
			if(newUrl!=''){
				var lastChar = newUrl.slice(-1);
				if((lastChar == "&") || ((lastChar == "?"))) {
					newUrl = newUrl.substring(0, newUrl.length-1);
				}
			}
			console.log(str);
			history.replaceState('data to be passed', 'Title of the page', newUrl);
		}
 
        function replaceQueryParam(param, newval, search) {
            var regex = new RegExp("([?;&])" + param + "[^&;]*[;&]?");
            var query = search.replace(regex, "$1").replace(/&$/, '');
            return (query.length > 2 ? query + "&" : "?") + (newval ? param + "=" + newval : '');
        }
 
        function getActualQuery(input_element) {
            var selected = [];
            var actual_q = '';
            $(input_element).each(function() {
                selected.push($(this).val());
            });
            if (selected.length > 1) {
                actual_q = selected.join(',');
            } else {
                actual_q = selected[0];
            }
            return actual_q;
        }
 
        function getSeeAllTopics() {
            var optHtml = '<div class="row">';
            var options = $('select[name="all_topics[]"] option');
            var rcnt = 1;
            $('select[name="all_topics[]"]').find('option').each(function() {
                var value = $(this).val();
                var text = $(this).text();
                var checked = "";
                if($(this).attr("selected") == "selected"){
                    checked = "checked";
                }
                if(value!="" && text!="") {
                    optHtml += '<div class="col-md-4">';
                    optHtml += '<div class="checkbox"><label><input type="checkbox" value="'+value+'" '+checked+'><span>'+text+'</span></label></div>';
                    optHtml += '</div>';
                    if(rcnt%3 == 0){
                        optHtml += '<div class="clearfix"></div>';
                    }
                    rcnt++;
                }
            });
            optHtml += '</div>';
            $('#seeAllTopic .modal-body').html(optHtml);
        }
 
		function applyMultiSelectBootstrap() {
			var $queryFields = getQueryFields();
			$.each($queryFields, function (key, value) {
				if (value && ((key != "all_topics[]") && (key != "other_topics[]"))) {
					if (isNaN(value)) {
						$("[name='"+key+"']").multiselect({
							buttonText: function(options, select) {
								return value;
							},
							buttonTitle: function(options, select) {
								var labels = [];
								options.each(function () {
									labels.push($(this).text());
								});
								return labels.join(', ');
							}
						});
					}
					else {
						$("[name='"+key+"']").multiselect();
					}
				}
			});          
		}
 
        function getQueryParams(qs) {
            qs = qs.split('+').join(' ');
            var params = {},
                tokens,
                re = /[?&]?([^=]+)=([^&]*)/g;
            while (tokens = re.exec(qs)) {
                params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
            }
            return params;
        }
                               
		function getQueryFields() {
			var $queryFields = {
				"type[]": 'Content Type',
				"langcode": 'Language',
				"topic[]": 'Topics',
				"all_topics[]": 'All Topics',
				"other_topics[]": 'Other Topics',
				"sort_bef_combine" : 1,
				"combine" : 0,
				"language": 'Language',
				"gender" : 'Gender',
				"center" : 'Locations',
				"city" : 0,
				"page" : 0,
				"section": 'View All',
			};
			return $queryFields;
		}
 
        function isInArray(value, array) {
          return array.indexOf(value) > -1;
        }
 
        function openAllTopicsPopup() {
            $(document).click();                   
            $("[name='topic[]']").multiselect('deselect', "seeall");                   
            $('#seeAllTopic').modal('show');
            return;
        }
 
		applyMultiSelectBootstrap();
		generateGridValues();
		getSeeAllTopics();
 
        var allTopicChkBox = $('#seeAllTopic');
        $(allTopicChkBox).on('click', 'input[type="checkbox"]', function(){
            if($(this).prop( "checked")) {
                var optionVal = $(this).val();
                var optSelector = "select[name='all_topics[]'] option[value='" + optionVal + "']";
                $('#seeAllTopic').modal('hide');
                $(optSelector).attr("selected", "selected");
                $("select[name='all_topics[]']").trigger('change');
            }
            else {
                var optionVal = $(this).val();
                var optSelector = "select[name='all_topics[]'] option[value='" + optionVal + "']";
                $('#seeAllTopic').modal('hide');
                $(optSelector).attr("selected", "");
            }
        });
 
        $(".filter-details").on("click", ".filter-close", function() {
            var optionVal = $(this).attr('data-id');
            var parentId = $(this).parent().attr('parent-id');
            var optSelector = "select#" + parentId + " option[value='" + optionVal + "']";
            $(optSelector).prop("selected", false);
            ddOptionsRebuild();
            generateQueryStringToUrl();
            filterFormSubmit();
        });
        function resetDefualt(){
			var optSelectorlang = "form[data-bef-auto-submit-full-form] .form-item-langcode option";
			var optSelector = "form[data-bef-auto-submit-full-form] .form-item-topic option";
			var optSelectorType = "form[data-bef-auto-submit-full-form] .form-item-type option";
			var optionOrder = "form[data-bef-auto-submit-full-form] .form-item-sort-bef-combine option:nth-child(2)";
			//$(optSelectorlang).prop("selected", false);
			$(optSelector).prop("selected", false);
			$(optSelectorType).prop("selected", false);
			$(optionOrder).prop("selected", true);
		}
        $(".filter-details").on("click", "#clearAll", function() {
        	var optSelector = "form[data-bef-auto-submit-full-form] option";
            $(optSelector).prop("selected", false);
            $('[name="combine"]').val('');
			$('[name="city"]').val('');
            resetDefualt();
            ddOptionsRebuild();
            filterFormSubmit();
        });
		$('.form-item-langcode .multiselect-container li').each(function() {
			$(this).children('a').click(function(e) {
				var lang = $(this).children().children().val();		
				resetDefualt();
				$('[name="combine"]').val('');
				var url = '?langcode='+lang+'&sort_bef_combine=created%20DESC';
				//window.history.pushState(null, document.title, url);
				//location.reload();
			});	 
		 });
		
		function pagerUrl(){
			var urlStr = document.URL;
			var queryString = window.location.search;
			if($('.view-display-id-block_8').length > 0) {
				var checkStrPage = queryString.substring(queryString.lastIndexOf("&") + 1, queryString.length);
				if(queryString){
					var defUrl = '&page=1';
				}else{
					var defUrl = '?langcode=en&sort_bef_combine=created%20DESC&page=1';
				}
				
			}else{
				var checkStrPage = queryString.substring(queryString.lastIndexOf("?") + 1, queryString.length);
				var defUrl = '?page=1';
			}	
			//alert(checkStrPage);
			var strPage = checkStrPage.split("=");
			var pageStr =strPage[0];
			//alert(pageStr);
			var lastStr = queryString.substring(queryString.lastIndexOf("=") + 1, queryString.length);
			var restStr = urlStr.substring(0, urlStr.lastIndexOf("=") + 1);
			var pageIndex =parseInt(lastStr);
			var currentIndex = pageIndex+1;
			if(queryString !=''){
				if(pageStr !='page'){
					//alert('VVV');
					var customPath = urlStr+defUrl;
				}else{
					var customPath = restStr+currentIndex;
				}
				
			}else{
				var customPath = urlStr+defUrl;	
			}
			$("ul.js-pager__items li.pager__item a.button").attr("href", customPath);	
		}
		//if($('.view-display-id-block_8').length > 0) {
			//pagerUrl();
		//}
        $(".btn-filter-submit").click(function(event) {
            event.preventDefault();
			generateQueryStringToUrl();
            filterFormSubmit();
			
        });
 
        $("[name='combine']").keypress(function(e) {
			if(e.which == 13) {
				filterFormSubmit();               
			}           
		});
 
        $("a[rel='next']").click(function(){
            var hrefUrl = $(this).attr('href');
            var hrefUrlSplit = hrefUrl.split("?");
            var hrefUrlQuery = getQueryParams(hrefUrlSplit[1]);
            var paramsObj = {};
            if(hrefUrlQuery.page != '') {
                paramsObj.page = hrefUrlQuery.page;
            }
            generateQueryStringToUrl(paramsObj);
        });
 
        $('select[name="all_topics[]"]').hide();
        $('select[name="other_topics[]"]').hide();
        $(".view-filters").fadeIn('slow');
 
        // The change event bubbles so we only need to bind it to the outer form.
        $('form[data-bef-auto-submit-full-form]', context)
            .add('[data-bef-auto-submit]', context)
            .filter('form, select, input:not(:text, :submit)')
            .once('bef-auto-submit')
            .change(function(e) {
                // don't trigger on text change for full-form
 
                var optionValues = $(e.target).val();
                if($.isArray(optionValues)) {
                    if($.inArray("seeall", optionValues) != -1) {
                        openAllTopicsPopup();
                        return;
                    }
                }
                else if(optionValues == "seeall"){
                    openAllTopicsPopup();
                    return;
                }
 
                if ($(e.target).is(':not(:text, :submit, [data-bef-auto-submit-exclude])')) {                
                    $(document).click();
                    generateQueryStringToUrl();
                    generateGridValues();                   
                    triggerSubmit.call(e.target.form);
                }
            });
 
        applyMultiSelectBootstrap();
        generateGridValues();
        getSeeAllTopics();       
    }
  };
})(jQuery, Drupal);
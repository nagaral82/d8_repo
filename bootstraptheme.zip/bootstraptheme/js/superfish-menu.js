(function($, Drupal) {

    "use strict";
    // All the JavaScript for this file.

    Drupal.behaviors.superfish_menu = {
        attach: function(context, settings) {

            if (window.matchMedia('(max-width: 1300px)').matches) {
                $('.navbar-collapse').insertAfter('.isha-header-mobile-tab .container .mobile-right-header');

                var spanTag = '<span class="sf-sub-indicator"> Â»</span>';
                $('.sf-depth-2 a.menuparent').append(spanTag);
            }
            $('.top-menu').css('display', 'none');
            $('.isha-header-mobile-tab').on('click', '.menu-btn', function(e) {
				$('.isha-header-mobile-tab .isha-header-container').addClass('rem-conatiner');
                $('.top-menu').css('display', 'block');
				$('.isha-logo-mobile.pull-left').css('display', 'none');
				$('.mobile-right-header.pull-right').css('display', 'none');
                $('.sf-accordion').show();
                $('.sf-accordion-toggle').hide();
				$('#navbar-collapse #topLinks2').css('display', 'block');
                $('.page-node-type-isha-posts #stickySocialrow').css('display', 'none');
				$('.registration-model-window #stickySocialrow').css('display', 'none');
                $('#superfish-ishanav-accordion').removeClass('sf-hidden');
                $('#superfish-ishanav-accordion').addClass('sf-expanded');
                $('.isha-menu-left').addClass('mobile-menu-left');
                $('.isha-menu-right').insertAfter('.isha-menu-left');
                $('.isha-menu-right .menu li:last-child').hide();
                $('.isha-header-top #topLinks2').insertAfter('.isha-menu-right');
                $('#topLinks2 .navbar-nav li:last-child').hide();
                $('a[href*="ishanga-training"]').parent().css('background-color', '#f5f1e9');
                if ($('.isha-menu-left').css('display', 'none')) {
                    $('.isha-menu-left').css('display', 'block ');
                    $('.isha-menu-right').css('display', 'block');
                    $('.navbar-nav').css('display', 'block');
                } else {
                    console.log('superfish menu error');
                }

            });
            $('#userLoggedin .menu-close').on('click', function(e) {
                $('.mobile-nav .menu-btn').click();
				$('.isha-header-mobile-tab .isha-header-container').removeClass('rem-conatiner');
				$('.isha-logo-mobile.pull-left').css('display', 'block');
				$('.mobile-right-header.pull-right').css('display', 'block');
                $('#navbar-collapse #topLinks2').css('display', 'none');
                $('#superfish-ishanav-accordion').css('display', 'none');
                $('.mobile-nav .menu-btn').css('display', 'block');
                $('#navbar-collapse .isha-menu-right.pull-right').css('display', 'none');
                $('#navbar-collapse .top-menu').css('display', 'none');
                $('.page-node-type-isha-posts #stickySocialrow').css('display', 'block');
				$('.registration-model-window #stickySocialrow').css('display', 'block');
            })

            window.addEventListener("resize", function() {
                var mql = window.matchMedia("(orientation: landscape)");
                var isiPad = /ipad/i.test(navigator.userAgent.toLowerCase());
                if (mql && isiPad && window.matchMedia('(width: 1366px)').matches) {
                    $('.navbar-collapse').appendTo('.isha-header-desktop .container');
                    $('.isha-menu-left').insertAfter('.isha-menu-right');
                    $('.isha-menu-right .menu li:last-child').show();
                    $('#topLinks2').appendTo('.isha-header-top .container');
                    $('#topLinks2 .navbar-nav li:last-child').show();
                    $('html').addClass('touch');
                } else if (window.matchMedia('(min-width: 1024px)').matches && window.matchMedia('(max-width: 1300px)').matches && window.matchMedia("(orientation: portrait)")) {
                    window.setTimeout(function() {
                        $('.sf-accordion-toggle').hide();
                        $('#superfish-ishanav-accordion').removeClass('sf-hidden');
                        $('#superfish-ishanav-accordion').addClass('sf-expanded');
                    }, 100);
                    $('.isha-menu-right').insertAfter('.isha-menu-left');
                    $('.isha-menu-right .menu li:last-child').hide();
                    $('.isha-header-top #topLinks2').insertAfter('.isha-menu-right');
                    $('#topLinks2 .navbar-nav li:last-child').hide();
                    $('.navbar-collapse').insertAfter('.isha-header-mobile-tab .container .mobile-right-header');
                    var spanTag = '<span class="sf-sub-indicator"> Â»</span>';
                    $('.sf-depth-2 a.menuparent').once('superfish_menu').append(spanTag);
                }
            }, false);

            $('.isha-header .isha-menu-left').on('click', '.sf-sub-indicator', function(e) {
                if (window.matchMedia('(max-width: 1300px)').matches) {
                    e.stopPropagation();
                    //e.preventDefault();
                }
            });

            $('.isha-header .isha-menu-left').once('superfish_menu').on('click', 'li.menuparent a', function(e) {
                var isiPad = /ipad/i.test(navigator.userAgent.toLowerCase());
                if (isiPad && window.matchMedia('(width: 1366px)').matches) {
                    if ($(this).hasClass('sf-depth-1')) {
                        e.preventDefault();
                        if ($(this).hasClass('navigate')) {
                            window.location = $(this).attr('href');
                        } else {
                            $(this).addClass('navigate');
                        }
                    }
                } else if (window.matchMedia('(max-width: 1300px)').matches) {
                    $(this).parent().removeClass('sf-expanded');
                    $(this).parent().find('ul').addClass('sf-hidden');
                    $(this).parent().find('ul').removeClass('sf-has-clone-parent');
                    window.location = $(this).attr('href');
                }
            });
        }
    }
})(jQuery, Drupal);
// http://leafo.net/sticky-kit/#reference
jQuery('.js-sticky').stick_in_parent({
    'parent': jQuery('.js-sticky-container'),
    'offset_top': 10
}).on('sticky_kit:bottom', function(e) {
    jQuery(this).parent().css('position', 'static');
}).on('sticky_kit:unbottom', function(e) {
    jQuery(this).parent().css('position', 'relative');
});

// jQuery.fn.equalHeights = function() {
//     var max_height = 0;
//     jQuery(this).each(function() {
//         max_height = Math.max(jQuery(this).height(), max_height);
//     });
//     jQuery(this).each(function() {
//         jQuery(this).height(max_height);
//     });
// };

function onScroll(event) {
    var scrollPos = jQuery(document).scrollTop();
    jQuery('#left-menu-center a').each(function() {
        var currLink = jQuery(this);
        var refElement = jQuery(currLink.attr("href"));
        if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            jQuery('#left-menu-center ul li a').removeClass("active");
            currLink.addClass("active");
        } else {
            currLink.removeClass("active");
        }
    });
}

function scrollToPositionOnPageLoad() {
    var currentHref = window.location.href;
    var divId = "#" + currentHref.substr(currentHref.lastIndexOf('/') + 1);
    if (jQuery(divId).length) {
        if (jQuery('#left-menu-center').is(':visible')) {
            jQuery('html, body').stop().animate({
                'scrollTop': jQuery(divId).offset().top + 2
            }, 500, 'swing', function() {
                jQuery(document).on("scroll", onScroll);
            });
        }
    }
}

jQuery(document).ready(function() {
    //scroll to sub-section on page load
    scrollToPositionOnPageLoad();

    // jQuery('.relative-height').equalHeights();
    jQuery(document).on("scroll", onScroll);

    //smoothscroll
    jQuery('#left-menu-center a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        jQuery(document).off("scroll");

        jQuery('a.cssticky').each(function() {
            jQuery(this).removeClass('active');
        })
        jQuery(this).addClass('active');

        var target = this.hash,
            menu = target;
        $target = jQuery(target);
        jQuery('html, body').stop().animate({
            'scrollTop': $target.offset().top + 2
        }, 500, 'swing', function() {
            window.location.hash = target;
            jQuery(document).on("scroll", onScroll);
        });
    });

});